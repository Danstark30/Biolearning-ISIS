# -*- coding: utf-8 -*-
"""
Created on Sun Apr 16 19:14:59 2023

@author: DANIEL
"""
import pandas as pd
from imblearn.over_sampling import SMOTE
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import RobustScaler
from sklearn.preprocessing import PowerTransformer
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
import warnings
#from sklearn.pipeline import make_pipeline
#from imblearn.over_sampling import RandomOverSampler
#from imblearn.under_sampling import RandomUnderSampler
from sklearn.metrics import roc_auc_score, confusion_matrix, accuracy_score, precision_score, recall_score, f1_score
from sklearn.ensemble import GradientBoostingClassifier
#from imblearn.over_sampling import SMOTE
# suppress warnings

warnings.filterwarnings('ignore')

df_encoded = pd.read_csv('encoded_data.csv')

resampler = SMOTE(random_state=42)

# Resample the data using the resampler
x_resampled, y_resampled = resampler.fit_resample(df_encoded.drop('Tipo de Cita_CANCELADA', axis=1), df_encoded['Tipo de Cita_CANCELADA'])

# Create a new encoded dataframe with the resampled data
df_encoded_smote = pd.concat([pd.DataFrame(x_resampled, columns=df_encoded.drop('Tipo de Cita_CANCELADA', axis=1).columns), pd.DataFrame(y_resampled, columns=['Tipo de Cita_CANCELADA'])], axis=1)



'''
# define input features and target variable
x = df_encoded.drop('Tipo de Cita_CANCELADA', axis=1)
y = df_encoded['Tipo de Cita_CANCELADA']
'''

#df_encoded = pd.DataFrame(ohe.fit_transform(df[columns]), columns=ohe.get_feature_names(columns))

# split the data into training and testing sets
x_train, x_test, y_train, y_test = train_test_split(x_resampled, y_resampled , test_size=0.2, random_state=42)
#x_train, x_test, y_train, y_test = train_test_split(x, y , test_size=0.2, random_state=42)

# define the scalers to compare
scalers = [StandardScaler(), MinMaxScaler(), RobustScaler(), PowerTransformer()]

#classifiers = [KNeighborsClassifier(n_neighbors=5,p=2, metric='euclidean', weights='uniform'),    RandomForestClassifier(n_estimators=100, random_state=42),    LogisticRegression(random_state=42)]

classifiers = [KNeighborsClassifier(n_neighbors=5,p=2, metric='euclidean', weights='uniform'),   
               RandomForestClassifier(n_estimators=100, random_state=42),    
               GradientBoostingClassifier()]




#classifiers =[LogisticRegression(random_state=42),GradientBoostingClassifier(),GaussianNB()]
e=0

# loop through the scalers and fit a random forest classifier pipeline to the data
'''
for cf in classifiers:
    i=0
    print('\n')
    print(classifiers[e])
    print('\n')

    for sc in scalers:
        pipe = Pipeline([('scaler', sc),('clf', cf)])
        pipe.fit(x_train, y_train)
        y_pred = pipe.predict(x_test)
        train_score = pipe.score(x_train, y_train)
        test_score = pipe.score(x_test, y_test)
        auc_score = roc_auc_score(y_test, y_pred)
        cm = confusion_matrix(y_test, y_pred)
        acc_score = accuracy_score(y_test, y_pred)
        prec_score = precision_score(y_test, y_pred)
        rec_score = recall_score(y_test, y_pred)
        f1 = f1_score(y_test, y_pred)
        
        print(f'Scaler: {sc.__class__.__name__}')
        print(f'Train score: {train_score:.2f}')
        print(f'Test score: {test_score:.2f}')
        print(f'AUC score: {auc_score:.2f}')
        print(f'Confusion Matrix:\n {cm}')
        print(f'Accuracy: {acc_score:.2f}')
        print(f'Precision: {prec_score:.2f}')
        print(f'Recall: {rec_score:.2f}')
        print(f'F1 Score: {f1:.2f}')
        print('-' * 30)
        i+=1
    e+=1
    '''
for cf in classifiers:
    i=0
    print('\n')
    print(classifiers[e])
    print('\n')

    for sc in scalers:
        pipe = Pipeline([('scaler', sc),('clf', cf)])
        pipe.fit(x_train, y_train)
        y_pred = pipe.predict(x_test)
        train_score = pipe.score(x_train, y_train)
        test_score = pipe.score(x_test, y_test)
        cm = confusion_matrix(y_test, y_pred)
        auc_score = roc_auc_score(y_test, y_pred)
        sensitivity = recall_score(y_test, y_pred, pos_label=1)
        specificity = recall_score(y_test, y_pred, pos_label=0)
        acc_score = accuracy_score(y_test, y_pred)
        prec_score = precision_score(y_test, y_pred)
        rec_score = recall_score(y_test, y_pred)
        f1 = f1_score(y_test, y_pred)
        
        print(f'Scaler: {sc.__class__.__name__}')
        print(f'Train score: {train_score:.2f}')
        print(f'Test score: {test_score:.2f}')
        print(f'Sensitivity (Recall of Positive Class): {sensitivity:.2f}')
        print(f'Specificity (Recall of Negative Class): {specificity:.2f}')
        print(f'AUC score: {auc_score:.2f}')
        print(f'Confusion Matrix:\n {cm}')
        print(f'Accuracy: {acc_score:.2f}')
        print(f'Precision: {prec_score:.2f}')
        print(f'Recall: {rec_score:.2f}')
        print(f'F1 Score: {f1:.2f}')
        metric = auc_score + sensitivity + specificity + acc_score + f1 + prec_score
        print(metric)
        print('-' * 30)
        metric=0
        i+=1
    e+=1